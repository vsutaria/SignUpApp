package com.example.assignment_one;

import android.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.scrounger.countrycurrencypicker.library.Buttons.CountryCurrencyButton;
import com.scrounger.countrycurrencypicker.library.Country;
import com.scrounger.countrycurrencypicker.library.Currency;
import com.scrounger.countrycurrencypicker.library.Listener.CountryCurrencyPickerListener;

import java.util.Calendar;

public class UpDateInfo extends AppCompatActivity  {


    static String country = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_up_date_info);

        Intent intent = getIntent();
        String pass = intent.getStringExtra(SignUp.KEY_PASS);



        EditText name = findViewById(R.id.name_et);
        EditText username= findViewById(R.id.username_et);
        EditText password= findViewById(R.id.password_et);
        EditText age= findViewById(R.id.age_et);
        EditText postal_address= findViewById(R.id.postal_code_et);

        Button  date_picker = findViewById(R.id.date_picker);


        CountryCurrencyButton button = (CountryCurrencyButton) findViewById(R.id.country_selector_test);
        button.setOnClickListener(new CountryCurrencyPickerListener() {
            @Override
            public void onSelectCountry(Country country) {
                if (country.getCurrency() == null) {
                    Toast.makeText(UpDateInfo.this,
                            String.format("name: %s\ncode: %s", country.getName(), country.getCode())
                            , Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(UpDateInfo.this,
                            String.format("name: %s\ncurrencySymbol: %s", country.getName(), country.getCurrency().getSymbol())
                            , Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onSelectCurrency(Currency currency) {

            }
        });

        password.setText(pass);

        /*Spinner spinner = (Spinner) findViewById(R.id.);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.country_array, android.R.layout.simple_spinner_item);



        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);*/



        date_picker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(UpDateInfo.this, AlertDialog.THEME_HOLO_DARK,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                                int given_day = day;
                                int given_month = month;
                                int given_year = year;

                                Calendar given_date= Calendar.getInstance();
                                given_date.set(given_year,given_month,given_day);

                                Calendar current_date = Calendar.getInstance();

                                int cal_age =  (current_date.get(Calendar.YEAR))- given_date.get(Calendar.YEAR);
                                if (current_date.get(Calendar.DAY_OF_YEAR) < given_date.get(Calendar.DAY_OF_YEAR))
                                {cal_age--;}

                                age.setText(Integer.toString(cal_age));
                            }
                        }, 0, 0, 0);
                datePickerDialog.show();
            }
        });
    }
}