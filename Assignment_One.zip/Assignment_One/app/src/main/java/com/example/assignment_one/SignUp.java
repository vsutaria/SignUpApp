package com.example.assignment_one;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class SignUp extends AppCompatActivity {

    boolean email_check=false;
    boolean pass_check=false;
    boolean pass_match_check=false;

    final static String  KEY_EMAIL ="KEY_EMAIL";
    final static String  KEY_PASS = "KEY_PASS";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_sign_up);

        EditText    email= findViewById(R.id.email_et);
        EditText    pass= findViewById(R.id.create_pass_et);
        EditText    pass_match = findViewById(R.id.pass_match_et);

        ImageView img_back = findViewById(R.id.back_img);
        Button btn = findViewById(R.id.btn_next);

        Drawable img_tick = this.getResources().getDrawable( R.drawable.tick);
        Drawable img_cross= this.getResources().getDrawable( R.drawable.cross);



        email.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if ( !hasFocus && (view.getId() ==email.getId())) {

                    boolean temp =isValidEmail(((EditText)view).getText().toString());
                    if (temp==true){
                        int h = img_tick.getIntrinsicHeight();
                        int w = img_tick.getIntrinsicWidth();
                        img_tick.setBounds( 0, 0, w, h );
                        email.setCompoundDrawables( null, null, img_tick, null );
                        email_check=true;


                    }
                    else {
                        int h = img_cross.getIntrinsicHeight();
                        int w = img_cross.getIntrinsicWidth();
                        img_cross.setBounds( 0, 0, w, h );
                        email.setCompoundDrawables( null, null, img_cross, null );


                    }
                }

            }
        });

       pass.setOnFocusChangeListener(new View.OnFocusChangeListener() {@Override
            public void onFocusChange(View view, boolean hasFocus) {
               if (!hasFocus && (view.getId() == pass.getId())) {
                   String temp = ((EditText) view).getText().toString();
                   if (temp.length() >= 8) {
                       if (check_pass(temp)) {
                           int h = img_tick.getIntrinsicHeight();
                           int w = img_tick.getIntrinsicWidth();

                           img_tick.setBounds(0, 0, w, h);
                           pass.setCompoundDrawables(null, null, img_tick, null);
                           pass_check=true;


                       } else {
                           int h = img_cross.getIntrinsicHeight();
                           int w = img_cross.getIntrinsicWidth();
                           img_cross.setBounds(0, 0, w, h);
                           pass.setCompoundDrawables(null, null, img_cross, null);
                       }

                   }
               }
           }



        });
        pass_match.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if ( !hasFocus && (view.getId() ==pass_match.getId())) {


                    if (((EditText)view).getText().toString().equals(pass.getText().toString())){
                        int h = img_tick.getIntrinsicHeight();
                        int w = img_tick.getIntrinsicWidth();
                        img_tick.setBounds( 0, 0, w, h );
                        pass_match.setCompoundDrawables( null, null, img_tick, null );
                        pass_match_check=true;
                        enable_btn(email_check,pass_check,pass_match_check,btn);



                    }
                    else {
                        int h = img_cross.getIntrinsicHeight();
                        int w = img_cross.getIntrinsicWidth();
                        img_cross.setBounds( 0, 0, w, h );
                        pass_match.setCompoundDrawables( null, null, img_cross, null );


                    }
                }

            }
        });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                Intent intent = new Intent(SignUp.this, UpDateInfo.class);


                intent.putExtra(KEY_PASS, pass.getText().toString());
                intent.putExtra(KEY_EMAIL,email.getText().toString());
                startActivity(intent);

            }
        });



        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }
    //"Your password should have minimum of 8 \n
    // character and contain at least one \n
    // number, one uppercase and one lower \n
    // case letter. You can use special characters."
    static boolean check_pass(String password) {


        boolean num_check = false;
        boolean up_check= false;
        boolean lc_check = false;


        for
        (int i = 0 ;i<password.length();i++) {


            if (Character.isUpperCase(password.charAt(i))){
                up_check= true;

            }
            if (Character.isLowerCase(password.charAt(i)))
            {
                lc_check=true;

            }
            if (Character.isDigit(password.charAt(i))){
                num_check=true;

            }
        }



        return (up_check && lc_check && num_check);
    }
    public static void enable_btn(boolean email_check, boolean pass_check, boolean pass_match_check, Button btn){

        if (email_check==true && pass_check == true &&  pass_match_check==true){

            btn.setEnabled(true); }
    }
    public static boolean isValidEmail(CharSequence target) {
        return target != null && android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }
}